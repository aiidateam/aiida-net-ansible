jQuery(document).ready(function($) {
//	var width = $("#customslider").width(), height = 500;
// Width has been hardcoded to the actual width it should have in the left column in the large screen view. 
// We cannot use the dynamic width defined in the above line because when loading the page in a small screen 
// the width would be set to zero and would stay like this also if after enlarged,
	var width = 375, height = 500;

        var selected_obj = null;
        var selected_node = null;

	var color = d3.scale.category20();

	var force = d3.layout.force()
	    .charge(-600)
	    .linkDistance(width/6)
	    .friction(0.7)
	    .gravity(0.1)
	    .size([width, height]);

	var svg = d3.select("#customslider").append("svg")
	    .attr("width", width)
	    .attr("height", height);

	// build the arrow.
	svg.append("svg:defs").selectAll("marker")
	    .data(["end"])
	    .enter().append("svg:marker")
	      .attr("id", String)
	      .attr("viewBox", "0 -5 10 10")
	      .attr("refX", 20)
	      .attr("markerWidth", 6)
	      .attr("markerHeight", 6)
	      .attr("orient", "auto")
	      .append("svg:path")
	        .attr("d", "M0,-5L10,0L0,5")
	        .attr("class", "arrow");


	d3.json("dbexample.json", function(error, graph) {

	  for (var i=0; i < graph.nodes.length; i++) {
        graph.nodes[i].x = Math.random()*width;
        graph.nodes[i].y = Math.random()*height;
      }

	  force
	     .nodes(graph.nodes)
	     .links(graph.links)
	     .start();

	  var link = svg.append("svg:g").selectAll("path")
	     .data(graph.links)
	     .enter().append("svg:path")
	     .attr("class", "link")
	     .style("marker-end", "url(#end)");

	  var node = svg.selectAll(".node")
	     .data(graph.nodes)
	     .enter().append("svg:g").call(force.drag);

	  node.append("title")
	     .text(function(d) { return d.name; });

	  force.on("tick", function() {
	     link.attr("d", function(d) {
	        return "M" + 
	            d.source.x + "," + 
	            d.source.y + "L" + 
	            d.target.x + "," + 
	            d.target.y;
	     });
	     node.attr("transform", function(d) {
	         return "translate(" + d.x + "," + d.y + ")"; 
	      });
	  });




	node.append("circle")
		.attr("class", "node")
		.attr("r", 10)

	node.append("title")
		.text(function(d) { return d.name + "(#" + d.id + ")";})

	node
	  .append("path")
	  .attr("d", d3.svg.symbol().type(
	  	function(d) {
	  		if (d.calculation== true) {return "square"} else {return "circle"}
	  	}).size(750))
	  .style("fill", function(d) { return color(d.group); })
	  .on('mouseover', function(d) {
	     d3.select(this).attr('transform', 'scale(1.1)');
	      })
	  .on('mouseout', function(d) {
	    d3.select(this).attr('transform', '');
	      })
	  .on('click', function(d) {
	    if( ! d3.event.ctrlKey) return;

	    // select node
	    mousedown_node = d;

	    // unselect previous node
	    if (selected_obj != null)
	    {
	       d3.select(selected_obj).style('stroke', '#fff');
	       //hide_tooltip();
	    }
	    if(mousedown_node === selected_node)
	    {
	      selected_node = null;
	      selected_obj = null;
	    }
	    else 
	    {
	      selected_node = mousedown_node;
	      selected_obj = this;
	      d3.select(this).style('stroke', 'red');
	      //show_tooltip(get_text(mousedown_node));
	    }

	  });


	node.append("svg:text")
      .attr("class", "text")
      .style("pointer-events", "none")
      .attr("dx", 20)
      .attr("dy", ".35em")
      .text(function(d) { return d.name;});


	});
});
