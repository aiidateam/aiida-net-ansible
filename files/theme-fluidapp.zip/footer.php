			<div class="bottom_shadow"></div>
		</div>
		<!-- End Pages -->

		<div class="clear"></div>
	</section>
	
	<!-- Start Footer -->
	<footer class="container">
		<p><?php echo stripslashes(get_option('t2t_footer_copyright')); ?></p>
	</footer>
	<!-- End Footer -->
	
	</div>
	<!-- End Wrapper -->
	
	<!-- Start Wordpress Footer Hook -->
	<?php wp_footer(); ?>
	<!-- End Wordpress Footer Hook -->
	
</body>
</html>
